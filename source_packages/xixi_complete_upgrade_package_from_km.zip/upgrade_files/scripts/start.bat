@echo off
chcp 65001 >nul
echo ==========================================
echo   西西桌面伴侣 - 一键启动
echo ==========================================
echo.

REM 检查 Ollama
echo [检查] Ollama 服务...
curl -s http://localhost:11434/api/tags >nul 2>&1
if errorlevel 1 (
    echo [警告] Ollama 服务未运行。尝试启动...
    start /min cmd /c "ollama serve"
    timeout /t 3 /nobreak >nul
)

REM 启动程序
echo [启动] 正在启动西西...
python main.py

if errorlevel 1 (
    echo.
    echo [错误] 启动失败。请检查日志: logs/xixi.log
    pause
    exit /b 1
)
