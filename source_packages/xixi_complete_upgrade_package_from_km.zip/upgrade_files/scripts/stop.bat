@echo off
chcp 65001 >nul
echo ==========================================
echo   西西桌面伴侣 - 一键停止
echo ==========================================
echo.

REM 查找并关闭 Python 进程（西西）
echo [停止] 正在关闭西西...
taskkill /F /IM python.exe /FI "WINDOWTITLE eq 西西*" >nul 2>&1
taskkill /F /IM python.exe /FI "WINDOWTITLE eq *西西*" >nul 2>&1

REM 备用：查找包含 xixi 的进程
tasklist /FI "IMAGENAME eq python.exe" /FO CSV | findstr /I "xixi" >nul 2>&1
if not errorlevel 1 (
    for /f "tokens=2 delims=," %%a in ('tasklist /FI "IMAGENAME eq python.exe" /FO CSV ^| findstr /I "xixi"') do (
        set pid=%%a
        set pid=!pid:"=!
        taskkill /F /PID !pid! >nul 2>&1
    )
)

echo [停止] 正在卸载模型...
curl -s -X POST http://localhost:11434/api/generate -d "{\"model\":\"richardyoung/qwen3.6-27b-abliterated:latest\",\"prompt\":\"\",\"stream\":false,\"keep_alive\":0}" >nul 2>&1

echo.
echo ==========================================
echo   已停止
echo ==========================================
pause
