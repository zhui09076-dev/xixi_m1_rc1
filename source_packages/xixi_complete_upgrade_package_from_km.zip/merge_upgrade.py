#!/usr/bin/env python3
"""
西西桌面伴侣 - 升级合并脚本
将本包中的新/修改文件合并到原始 xixi_m1_rc1 仓库中
"""
import shutil
import sys
from pathlib import Path

def main():
    # 检测原始仓库路径
    repo_path = Path.cwd()
    if not (repo_path / "core" / "database.py").exists():
        print("[错误] 请在原始 xixi_m1_rc1 仓库根目录运行此脚本")
        print("用法: python merge_upgrade.py")
        sys.exit(1)

    # 升级包路径（假设与脚本同目录）
    upgrade_path = Path(__file__).parent / "upgrade_files"

    if not upgrade_path.exists():
        print(f"[错误] 找不到升级文件目录: {upgrade_path}")
        print("请确保 upgrade_files/ 目录与脚本在同一位置")
        sys.exit(1)

    print("=" * 50)
    print("西西桌面伴侣 - 升级合并")
    print("=" * 50)
    print()

    # 备份原始文件
    backup_dir = repo_path / "backup_before_upgrade"
    backup_dir.mkdir(exist_ok=True)
    print(f"[1/4] 备份原始文件到 {backup_dir}")

    files_to_replace = [
        "main.py",
        "config.yaml", 
        "requirements.txt",
        "core/__init__.py",
        "core/llm.py",
        "core/memory.py",
        "core/permission_gateway.py",
        "core/task_scheduler.py",
    ]

    for f in files_to_replace:
        src = repo_path / f
        if src.exists():
            dst = backup_dir / f.replace("/", "_")
            shutil.copy2(str(src), str(dst))

    # 替换文件
    print("[2/4] 替换修改的文件...")
    for f in files_to_replace:
        src = upgrade_path / f
        dst = repo_path / f
        if src.exists():
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(str(src), str(dst))
            print(f"  ✓ {f}")
        else:
            print(f"  ✗ 未找到: {f}")

    # 复制新增文件
    print("[3/4] 复制新增文件...")
    new_files = [
        "core/protocol_server.py",
        "core/soul_loader.py",
        "core/tool_executor.py",
        "core/body_interface.py",
        "core/web_bridge.py",
        "core/lifecycle.py",
        "ui/web_main_window.py",
        "scripts/install.bat",
        "scripts/start.bat",
        "scripts/stop.bat",
    ]

    for f in new_files:
        src = upgrade_path / f
        dst = repo_path / f
        if src.exists():
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(str(src), str(dst))
            print(f"  ✓ {f}")
        else:
            print(f"  ✗ 未找到: {f}")

    # 复制文档
    print("[4/4] 复制文档...")
    docs = [
        "docs/VERIFICATION_CHECKLIST.md",
        "docs/CHANGES_FROM_RC3.md",
        "docs/KNOWN_ISSUES.md",
        "README.md",
    ]

    for f in docs:
        src = upgrade_path / f
        dst = repo_path / f
        if src.exists():
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(str(src), str(dst))
            print(f"  ✓ {f}")

    print()
    print("=" * 50)
    print("升级完成!")
    print("=" * 50)
    print()
    print("下一步:")
    print("1. 安装新依赖: pip install -r requirements.txt")
    print("2. 确保 supplements/soul/xixi_soul_rc1/ 存在")
    print("3. 确保 supplements/ui_docs/xixi_ui_rc1/index.html 存在")
    print("4. 运行: scripts/start.bat")
    print()
    print("验证: 参见 docs/VERIFICATION_CHECKLIST.md")

if __name__ == "__main__":
    main()
